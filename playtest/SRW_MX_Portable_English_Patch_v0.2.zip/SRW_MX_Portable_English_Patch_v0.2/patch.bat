@echo off
setlocal EnableExtensions
title SRW MX Portable English patch (v0.2)
cd /d "%~dp0"

set "ISO=Super_Robot_Taisen_MX_Portable_JPN_PSP-Caravan.iso"
set "OUT=Super_Robot_Wars_MX_Portable_EN_v0.2.iso"
set "PATCH=MX_EN_v0.2.xdelta"
set "STOCK_MD5=448d168edcd3edfe62cdcb9b31c87820"
set "OUT_MD5=7998faa5e68f827c674686f1e6823536"

echo.
echo  Super Robot Wars MX Portable - English patch v0.2
echo  ------------------------------------------------
echo.

rem the ISO next to this kit, or one folder up (when the zip was unpacked into its own folder)
if not exist "%ISO%" if exist "..\%ISO%" cd ..
if not exist "%ISO%" (
  echo  ERROR: "%ISO%" is not in this folder.
  echo  Put this kit in the same folder as the Japanese ISO, with that exact name.
  goto :fail
)
set "KIT=%~dp0"
if not exist "%KIT%xdelta3.exe" (
  echo  ERROR: xdelta3.exe is missing from this folder. Unzip the whole kit here.
  goto :fail
)
if not exist "%KIT%%PATCH%" (
  echo  ERROR: %PATCH% is missing from this folder. Unzip the whole kit here.
  goto :fail
)

echo  [1/3] Checking your Japanese ISO (this takes a few seconds)...
call :md5 "%ISO%" H
if /i not "%H%"=="%STOCK_MD5%" (
  echo.
  echo  ERROR: this ISO is not the expected Japanese disc image.
  echo    found    %H%
  echo    expected %STOCK_MD5%
  echo  The patch only works on the original, unmodified ULJS-00041 ISO.
  goto :fail
)
echo        OK

echo  [2/3] Applying the English patch (about a minute)...
if exist "%OUT%" del /f /q "%OUT%"
"%KIT%xdelta3.exe" -d -s "%ISO%" "%KIT%%PATCH%" "%OUT%"
if errorlevel 1 (
  echo.
  echo  ERROR: xdelta3 could not apply the patch.
  if exist "%OUT%" del /f /q "%OUT%"
  goto :fail
)
echo        OK

echo  [3/3] Checking the English ISO...
call :md5 "%OUT%" H
if /i not "%H%"=="%OUT_MD5%" (
  echo.
  echo  ERROR: the new ISO did not come out right ^(md5 %H%^).
  goto :fail
)
echo        OK
echo.
echo  DONE. Your English ISO is:
echo    %CD%\%OUT%
echo  The Japanese ISO was not changed.
echo.
pause
exit /b 0

:fail
echo.
echo  Nothing was changed. Press any key to close.
pause >nul
exit /b 1

:md5
set "%2="
for /f "skip=1 delims=" %%h in ('certutil -hashfile "%~1" MD5') do (
  if not defined %2 set "%2=%%h"
)
call set "%2=%%%2: =%%"
exit /b 0
