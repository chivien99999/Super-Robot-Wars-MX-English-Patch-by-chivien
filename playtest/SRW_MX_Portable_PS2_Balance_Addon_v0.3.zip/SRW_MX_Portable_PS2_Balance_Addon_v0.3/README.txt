Super Robot Wars MX Portable - PS2 balance add-on (optional), for English version 0.3
=====================================================================================

The PSP release made enemies tougher than the PS2 original: about half again as
much HP (x1.5), with lower funds rewards (x0.8). This add-on puts back the PS2 numbers:
- 139 enemy HP values back to PS2
- 295 funds values back to PS2
Nothing else changes: same translation, same program, no code edits.
(G Gundam armor and the other PSP-only differences are left as PSP for now.)

How to use (Windows)
1. First make the English ISO with the main v0.3 kit:
     Super_Robot_Wars_MX_Portable_EN_v0.3.iso
2. Unzip this add-on into the folder that holds that English ISO (or into a
   folder inside it).
3. Double-click patch.bat and wait for "DONE". The new file is written next to it:
     Super_Robot_Wars_MX_Portable_EN_v0.3_PS2_balance.iso

Your English v0.3 ISO is never changed, so you can keep both and choose either one.

What patch.bat checks
- The input must be the English v0.3 ISO
  (1,357,854,720 bytes, MD5 107626c24452b89b4b7c2bea7045c40e).
- The new ISO is checked too
  (1,357,854,720 bytes, MD5 2a324590816727a03d548d87b2226e99).

Contents
- patch.bat                          the one-click patcher
- MX_EN_v0.3_PS2_balance.xdelta      the add-on patch (xdelta3, VCDIFF)
- xdelta3.exe                        xdelta 3.1.0, 64-bit Windows, the official build from
                                     https://github.com/jmacd/xdelta-gpl/releases/tag/v3.1.0
- README.txt                         this file

Other systems: xdelta3 -d -s Super_Robot_Wars_MX_Portable_EN_v0.3.iso MX_EN_v0.3_PS2_balance.xdelta Super_Robot_Wars_MX_Portable_EN_v0.3_PS2_balance.iso
