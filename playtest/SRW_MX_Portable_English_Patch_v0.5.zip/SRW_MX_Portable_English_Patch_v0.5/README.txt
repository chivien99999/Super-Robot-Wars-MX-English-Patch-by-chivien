Super Robot Wars MX Portable - English patch, v0.5
==================================================

How to use (Windows)
1. Unzip this kit into the folder that holds your Japanese ISO (or into a
   folder inside it):
     Super_Robot_Taisen_MX_Portable_JPN_PSP-Caravan.iso
2. Double-click patch.bat.
3. Wait for "DONE". The new file is written next to the Japanese ISO:
     Super_Robot_Wars_MX_Portable_EN_v0.5.iso

Your Japanese ISO is never changed. If a Super_Robot_Wars_MX_Portable_EN_v0.5.iso
is already in the folder, it is replaced.

What patch.bat checks
- The Japanese ISO must be the original ULJS-00041 image
  (1,295,122,432 bytes, MD5 448d168edcd3edfe62cdcb9b31c87820).
- The new ISO is checked too
  (1,357,854,720 bytes, MD5 53d0282c9a3cf1ccf120925faaff17fe).

Contents
- patch.bat         the one-click patcher
- MX_EN_v0.5.xdelta   the patch (xdelta3, VCDIFF)
- xdelta3.exe       xdelta 3.1.0, 64-bit Windows, the official build from
                    https://github.com/jmacd/xdelta-gpl/releases/tag/v3.1.0
- README.txt        this file

On a real PSP the patched ISO needs custom firmware, like any ISO. In the
patched ISO, EBOOT.BIN is the decrypted, translated game program.

Other systems: xdelta3 -d -s Super_Robot_Taisen_MX_Portable_JPN_PSP-Caravan.iso MX_EN_v0.5.xdelta Super_Robot_Wars_MX_Portable_EN_v0.5.iso
