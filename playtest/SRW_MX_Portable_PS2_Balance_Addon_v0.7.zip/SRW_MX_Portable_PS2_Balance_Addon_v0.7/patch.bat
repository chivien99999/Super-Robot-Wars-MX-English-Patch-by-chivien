@echo off
setlocal EnableExtensions
title SRW MX Portable - PS2 balance add-on (for English v0.7)
cd /d "%~dp0"

set "ISO=Super_Robot_Wars_MX_Portable_EN_v0.7.iso"
set "OUT=Super_Robot_Wars_MX_Portable_EN_v0.7_PS2_balance.iso"
set "PATCH=MX_EN_v0.7_PS2_balance.xdelta"
set "STOCK_MD5=a18f013df02c07be18e2cfadeebee1b6"
set "OUT_MD5=4af46dec382ffd327b9c757a8f8becf9"

echo.
echo  Super Robot Wars MX Portable - English patch v0.7
echo  ------------------------------------------------
echo.

rem the ISO next to this kit, or one folder up (when the zip was unpacked into its own folder)
if not exist "%ISO%" if exist "..\%ISO%" cd ..
if not exist "%ISO%" (
  echo  ERROR: "%ISO%" is not in this folder.
  echo  Make the English v0.7 ISO first ^(main kit^), then put this add-on next to it.
  goto :fail
)
set "KIT=%~dp0"
if not exist "%KIT%xdelta3.exe" (
  echo  ERROR: xdelta3.exe is missing from this folder. Unzip the whole kit here.
  goto :fail
)
if not exist "%KIT%%PATCH%" (
  echo  ERROR: %PATCH% is missing from this folder. Unzip the whole kit here.
  goto :fail
)

echo  [1/3] Checking your English v0.7 ISO (this takes a few seconds)...
call :md5 "%ISO%" H
if /i not "%H%"=="%STOCK_MD5%" (
  echo.
  echo  ERROR: this is not the English v0.7 ISO made by the main kit.
  echo    found    %H%
  echo    expected %STOCK_MD5%
  echo  The add-on only works on that exact file ^(patch the Japanese ISO with the v0.7 kit first^).
  goto :fail
)
echo        OK

echo  [2/3] Applying the PS2 balance (a few seconds)...
if exist "%OUT%" del /f /q "%OUT%"
"%KIT%xdelta3.exe" -d -s "%ISO%" "%KIT%%PATCH%" "%OUT%"
if errorlevel 1 (
  echo.
  echo  ERROR: xdelta3 could not apply the patch.
  if exist "%OUT%" del /f /q "%OUT%"
  goto :fail
)
echo        OK

echo  [3/3] Checking the new ISO...
call :md5 "%OUT%" H
if /i not "%H%"=="%OUT_MD5%" (
  echo.
  echo  ERROR: the new ISO did not come out right ^(md5 %H%^).
  goto :fail
)
echo        OK
echo.
echo  DONE. Your English ISO with PS2 balance is:
echo    %CD%\%OUT%
echo  The English v0.7 ISO was not changed.
echo.
pause
exit /b 0

:fail
echo.
echo  Nothing was changed. Press any key to close.
pause >nul
exit /b 1

:md5
set "%2="
for /f "skip=1 delims=" %%h in ('certutil -hashfile "%~1" MD5') do (
  if not defined %2 set "%2=%%h"
)
call set "%2=%%%2: =%%"
exit /b 0
