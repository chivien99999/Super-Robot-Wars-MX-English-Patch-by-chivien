Super Robot Wars MX Portable - PS2 balance add-on (optional), for English version 0.4
=====================================================================================

The PSP release made enemies tougher than the PS2 original: about half again as
much HP (x1.5), with lower funds rewards (x0.8). This add-on puts back the PS2 numbers:
- 139 enemy HP values back to PS2
- 295 funds values back to PS2
Nothing else changes: same translation, same program, no code edits.
(G Gundam armor and the other PSP-only differences are left as PSP for now.)

How to use (Windows)
1. First make the English ISO with the main v0.4 kit:
     Super_Robot_Wars_MX_Portable_EN_v0.4.iso
2. Unzip this add-on into the folder that holds that English ISO (or into a
   folder inside it).
3. Double-click patch.bat and wait for "DONE". The new file is written next to it:
     Super_Robot_Wars_MX_Portable_EN_v0.4_PS2_balance.iso

Your English v0.4 ISO is never changed, so you can keep both and choose either one.

What patch.bat checks
- The input must be the English v0.4 ISO
  (1,357,854,720 bytes, MD5 4b0633e0cab0462202bbafd076c8b091).
- The new ISO is checked too
  (1,357,854,720 bytes, MD5 c4bf89c6c79f75744ffe7273c9700e80).

Contents
- patch.bat                          the one-click patcher
- MX_EN_v0.4_PS2_balance.xdelta      the add-on patch (xdelta3, VCDIFF)
- xdelta3.exe                        xdelta 3.1.0, 64-bit Windows, the official build from
                                     https://github.com/jmacd/xdelta-gpl/releases/tag/v3.1.0
- README.txt                         this file

Other systems: xdelta3 -d -s Super_Robot_Wars_MX_Portable_EN_v0.4.iso MX_EN_v0.4_PS2_balance.xdelta Super_Robot_Wars_MX_Portable_EN_v0.4_PS2_balance.iso
